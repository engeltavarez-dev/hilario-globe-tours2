import { getStore } from "@netlify/blobs";
import { timingSafeEqual } from "node:crypto";

const STORE_NAME = "hilario-globe-tour";
const STORE_KEY = "public-site-data";
const MAX_BODY_BYTES = 5_500_000;

function response(statusCode, payload) {
  return new Response(JSON.stringify(payload), {
    status: statusCode,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store, max-age=0",
      "X-Content-Type-Options": "nosniff"
    }
  });
}

function secureEqual(a, b) {
  const aa = Buffer.from(String(a || ""));
  const bb = Buffer.from(String(b || ""));
  return aa.length === bb.length && timingSafeEqual(aa, bb);
}

export default async (request) => {
  if (request.method === "OPTIONS") {
    return new Response(null, { status: 204 });
  }

  const store = getStore(STORE_NAME);

  if (request.method === "GET") {
    try {
      const data = await store.get(STORE_KEY, { type: "json" });
      return response(200, { data: data || null });
    } catch (error) {
      return response(500, { error: "No se pudieron leer los datos del sitio." });
    }
  }

  if (request.method !== "POST") {
    return response(405, { error: "Método no permitido." });
  }

  const expectedPin = Netlify.env.get("HGT_ADMIN_PIN");
  if (!expectedPin) {
    return response(503, { error: "Falta configurar HGT_ADMIN_PIN en las variables de entorno de Netlify." });
  }

  const suppliedPin = request.headers.get("x-admin-pin") || "";
  if (!secureEqual(suppliedPin, expectedPin)) {
    return response(401, { error: "PIN de administrador incorrecto." });
  }

  const raw = await request.text();
  if (Buffer.byteLength(raw, "utf8") > MAX_BODY_BYTES) {
    return response(413, { error: "El contenido es demasiado grande. Reduce el tamaño o la cantidad de fotos." });
  }

  let body;
  try {
    body = JSON.parse(raw);
  } catch {
    return response(400, { error: "La solicitud no contiene JSON válido." });
  }

  // La comprobación inicial valida el PIN sin escribir nada.
  if (body?.action === "auth") {
    return response(200, { ok: true });
  }

  if (!body?.data || !Array.isArray(body.data.tours)) {
    return response(400, { error: "Los datos del catálogo no tienen el formato esperado." });
  }

  try {
    await store.setJSON(STORE_KEY, body.data);
    return response(200, { ok: true, saved: true });
  } catch (error) {
    return response(500, { error: "No se pudieron guardar los cambios en el servidor." });
  }
};
